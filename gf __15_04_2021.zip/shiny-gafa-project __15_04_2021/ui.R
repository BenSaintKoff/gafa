
library(leaflet)
library(plotly)
library(shinydashboard)
library(shinyWidgets)
library(shinycssloaders)
library(shinythemes)
#library(shinydashboardPlus)


# Choices for drop-downs
axes <- c(
  "Type porteur" = "type_porteur",
  "Réseau de la carte" = "reseau_carte",
  "Nom de la carte" = "nom_carte"
  
)

indic <- c(
  "Montant des transactions" = "montant_transaction",
  "Nombre de transaction" = "nbre_transaction"
)

fluidPage(
  # tags$link(rel="stylesheet", type = "text/css",
  #           href="https://www.w3schools.com/w3css/4/w3.css"),
  # 
  # use this in non shinydashboard app
  #setBackgroundColor(color = "ghostwhite"),
  useShinydashboard(),
  useSweetAlert(theme = c("bulma"),ie = TRUE),
  tags$head(
    tags$style(HTML("
                    #nav {
                       padding-left:0px; padding-right:0px;
                    }"))),
  
navbarPage("GAFA |Cartographie DAB SGCI", id="nav", theme = shinytheme("cosmo"),
        
  
  tabPanel("Cartographie interactive", icon = icon("map-marker"),
    div(class="outer",

      tags$head(
        # Include our custom CSS
        includeCSS("styles.css"),
        includeScript("gomap.js")
      ),
      # If not using custom CSS, set height of leafletOutput to a number instead of percent
      leafletOutput("map", width="100%", height="100%"),

      # Shiny versions prior to 0.11 should use class = "modal" instead.
      absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE, style = "background-color:grey;",
        draggable = TRUE, top = 60, left = "auto", right = 20, bottom = "auto",
        width = 330, height = "auto",

        h3("DAB explorer"),
        dropdownButton(  status = "danger", circle = FALSE, icon = icon("home"), width = "250px",size = "xs",
          selectInput("color", "Axes d'analyse", axes),
          conditionalPanel("input.color == 'type_porteur'", 
                           awesomeRadio( 
                             inputId = "Id045", inline = FALSE, 
                             label = "Choix type porteur",
                             status = "danger",
                             choices = c("Global","CLIENT SG", "Concurrent"),
                             selected = "Global",
                             
                           )
          ),
          selectInput("size", "Indicateurs",indic, selected = "montant_transaction"),
          conditionalPanel("input.color == 'type_porteur' || input.size == 'montant_transaction'",
                           dateRangeInput("daterange1", "Période d'analyse:", separator = "au",language = "fr",
                                          end   = "2020-12-01",
                                          start = "2020-07-01",
                                          max   = "2020-12-01",
                                          min   = "2020-07-01"
                           )
          )
        ),hr(),

        plotlyOutput("histCentile", height = 200),hr(),
        plotlyOutput("scatterCollegeIncome", height = 250),br(),
        checkboxInput("somevalue", "Zoom sur Abidjan", FALSE)
      ),

      tags$div(id="cite",
        'Data compiled for ', tags$em('Coming Apart: Statistical data from Societe Generale ATMs'), ' by IP_TT:@Cellule data (Avril, 2021).'
      )
    )
  ),

  tabPanel("Statistique sur les DAB", icon = icon("chart-line"),
           fluidRow( style = "margin-left:20px;margin-right:20px;",
             column(width = 2,
                    dropdown(
                      
                      tags$h4("Menu d'analyse"),hr(),
                      dateRangeInput("datRange", "Période d'analyse", separator = "au", language = "fr",
                                     end   = "2020-12-01",
                                     start = "2020-07-01",
                                     max   = "2020-12-01",
                                     min   = "2020-07-01"
                                     ),
                      pickerInput(inputId = 'xcol2',
                                  label = 'Agence DAB',
                                  choices = unique(allzips$agence_dab),
                                  multiple = TRUE,
                                  
                                  ),
                      
                      pickerInput(inputId = 'ycol2',
                                  label = 'Indicateurs',
                                  choices = indic,
                                  selected = indic[1]
                                  ),
                      
                      
                      icon = icon("gear"),label = "Menu", size = "xs",
                      status = "danger", width = "300px", style = "jelly",
                      animate = animateOptions(
                        enter = animations$fading_entrances$fadeInLeftBig,
                        exit = animations$fading_exits$fadeOutRightBig
                      )
                    )
                    ),
             column(10,
                    column(width = 5, infoBoxOutput("info_montant", 10)),
                    column(width = 5, infoBoxOutput("info_transaction", 10)),
                    column(width = 2, tags$strong("PERIODE D'ANALYSE"),  textOutput("period"))
                    )
           ),hr(),
           
           fluidRow( style = "margin-left:20px;margin-right:20px;",
             fluidRow(
               conditionalPanel("input.ycol2 == 'montant_transaction'", box(h4(tags$strong("ANALYSE PAR MONTANT DE TRANSACTION")), 
                                                                            style = "width:50%; back-ground-color:grey;")),
               conditionalPanel("input.ycol2 == 'nbre_transaction'", h4(tags$strong("ANALYSE PAR NOMBRE DE TRANSACTION"))),br(),
                    column(width = 4,"Transaction par carte réseau",addSpinner(plotlyOutput("plot2"),spin = "circle", color = "#E41A1C" )),
                    column(width = 4,"Transaction par type réseau", addSpinner(plotlyOutput("plot3"), spin = "circle", color = "#E41A1C")),
                    column(width = 4,"Taux de transactions par carte / type réseau", br(),
                           dropdownButton(
                             prettyRadioButtons(inputId = "check_transaction",  label = "Transaction par:", 
                                                  choices = c("Type carte reseau", "Nom de la carte"), icon = icon("check"),  bigger = TRUE,
                                                  status = "info",animation = "jelly"),
                             circle = FALSE, status = "danger", size = "xs",
                             icon = icon("bars"), width = "200px",
                             tooltip = tooltipOptions(title = "Click to see inputs !")),
                           
                           addSpinner(plotlyOutput("plot4"), spin = "circle", color = "#E41A1C"))
                    ),hr(),
             fluidRow(
               column(width = 12, 
                 column(3,
                        selectInput("states", "Région/Département", c("Régions ou départements"="", structure(unique(cleantable[["Region ou departement"]]))),
                                    multiple=TRUE)
                 ),
                 column(3,
                        conditionalPanel("input.states",
                                         selectInput("cities", "Ville", c("Villes des DAB"="", structure(unique(cleantable[["Ville"]]))), multiple=TRUE)
                        )
                 ),
                 column(3,
                        conditionalPanel("input.states",
                                         selectInput("zipcodes", "Code DAB", c("Codes des DAB"=""), multiple=TRUE)
                        )
                 )
               ),
               hr(),
               column(DT::dataTableOutput("ziptable"),width = 12)
                    ),
             )
           ),

  conditionalPanel("false", icon("crosshair"))
))
