
library(leaflet)
library(RColorBrewer)
library(scales)
library(lattice)
library(dplyr)
library(htmltools)
library(htmlwidgets)
library(ggplot2)
library(hrbrthemes)
library(viridis)
library(leaflet.extras)
#library(shinyWidgets)


#  By ordering by centile, we ensure that the (comparatively rare) SuperZIPs
#  will be drawn last and thus be easier to see
zipdata <- allzips[order(allzips$montant_transaction),]

function(input, output, session) {

  ## Interactive Map ###########################################

  # Create the map
  output$map <- renderLeaflet({
    leaflet() %>%
      addTiles() %>%
      addProviderTiles(provider = providers$OpenStreetMap,
                       options  = providerTileOptions(minZoom = 8, maxZoom = 50)) %>% 
      addProviderTiles(providers$Thunderforest.Landscape) %>% 
      setView(lng = -4.021233, lat = 5.32426, zoom = 10 ) %>% 
      addSearchOSM() %>% 
      addResetMapButton()
  })
  
  # A reactive expression that returns the set of zips that are
  # in bounds right now
  zipsInBounds <- reactive({
    if (is.null(input$map_bounds))
      return(zipdata[FALSE,])
    bounds <- input$map_bounds
    latRng <- range(bounds$north, bounds$south)
    lngRng <- range(bounds$east, bounds$west)
    
    if (input$daterange1[2] < max.date| input$daterange1[1] > min.date )
    subset(zipdata,
      latitude >= latRng[1] & latitude <= latRng[2] &
        longitude >= lngRng[1] & longitude <= lngRng[2])
    else {
          subset(zipdata,
                 latitude >= latRng[1] & latitude <= latRng[2] &
                   longitude >= lngRng[1] & longitude <= lngRng[2] &
                   mois >= input$daterange1[1] & mois <= input$daterange1[2])
            
        }
  })

  # Barplot of type of  card's network
  output$histCentile <- renderPlotly({
                         zipsInBounds() %>% group_by(reseau_carte, type_porteur) %>%
                          summarise(`Nombre de transaction` = sum(nbre_transaction, na.rm = TRUE)/1e6,
                                    .groups = 'drop') %>%
                        plot_ly(type = "bar",
                                x = ~reseau_carte,
                                y = ~`Nombre de transaction`,
                                color = ~type_porteur,
                                colors = c("#c50022", "#F1C40F"),
                                hoverinfo = 'text',
                                text = ~ paste0(`Nombre de transaction`, " transactions"),
                                showlegend = TRUE) %>%
                        layout(
                          xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                          yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    
                        
                      
  
  })
  
  # Scatter plot of transaction amount
  output$scatterCollegeIncome <- renderPlotly({
                        zipsInBounds() %>% group_by(code_agence_dab,  type_porteur) %>%
                          summarise(`Nombre transaction` = mean(nbre_transaction), `Montant transaction` = mean(montant_transaction),
                                    .groups = 'drop') %>% 
                          plot_ly(type='scatter', x = ~`Montant transaction`, y= ~`Nombre transaction`, mode = 'markers',
                                  fill = ~'',
                                  marker = list(sizemode = 'diameter'),
                                  color = ~type_porteur,
                                  colors = c("#c50022", "#F1C40F")
                                  ) %>%
                            layout(
                              xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                              yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
  })
  
  # # This observer is responsible for maintaining the circles and legend,
  # # according to the variables the user has chosen to map to color and size.
  observe({
    req(input$color)
    req( input$size)
    req(input$Id045)
    colorBy <- input$color
    sizeBy  <- input$size
    
    # if the checkbock statut is not avalaible
   if (input$Id045 == "Global"){
     # Update zip.map when date is entered
     if (input$daterange1[1] > min.date | input$daterange1[2] < max.date ){
       zip.map <- allzips %>%
         group_by(code_agence_dab,type_porteur,nom_carte, reseau_carte) %>% 
         summarise(latitude  = mean(latitude),
                   longitude = mean(longitude),
                   `Montant transaction` = sum(montant_transaction),
                   `Nombre transaction`  = round(sum(nbre_transaction)),
                   Adresse = adresse, lib_ville, lib_agence, .groups = 'drop')  %>% unique()
       
       zip.map_grouped <- zip.map %>% group_by(code_agence_dab) %>% 
         summarise(Montant = sum(`Montant transaction`), Nombre = sum(`Nombre transaction`))
       
       zip.map$Montant <- zip.map_grouped$Montant[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
       zip.map$Nombre  <- zip.map_grouped$Nombre[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
       #zip.map$id <- allzips$id[match(zip.map$code_agence_dab, allzips$code_agence_dab)]
       
       zip.map$label <- paste0("<div,class = 'container', style = 'color:#154360 '>
                <h4><center> Code Agence: ", zip.map$code_agence_dab ,"</center></h4></br>
                <center>" ,capitalize(zip.map$lib_agence),"</center><hr>",
                               "<b>Montant transation:</b><span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                               prettyNum(round(zip.map$Montant*1e6), " ") ," (XOF)</span></br>",
                               "<b>Nombre transation:</b>  <span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                               prettyNum( zip.map$Nombre, " ") ,"</span></br>",
                               "<b>Adresse:</b><em>  ", zip.map$Adresse ,"</em></h3>
                </div>") %>% 
         lapply(htmltools::HTML)
     }
     
     if (input$daterange1[1] != max.date | input$daterange1[2] != min.date ){
       if(lubridate::month(input$daterange1[1]) == lubridate::month(input$daterange1[2])){
         show_alert(
           title = "Erreur de date !!",
           text = "La période doit être comprise entre deux mois...",
           type = "warning",
           width = "400px"
         )
       }
       else{
         zip.map <- allzips[allzips$mois <= input$daterange1[2] & allzips$mois >= input$daterange1[1] ,] %>% 
           group_by(code_agence_dab, type_porteur, nom_carte, reseau_carte) %>% 
           summarise(latitude  = mean(latitude),
                     longitude = mean(longitude),
                     `Montant transaction` = sum(montant_transaction),
                     `Nombre transaction`  = round(sum(nbre_transaction)),
                     Adresse = adresse, lib_ville, lib_agence, .groups = 'drop')  %>% unique()
         
         zip.map_grouped <- zip.map %>% group_by(code_agence_dab) %>% 
           summarise(Montant = sum(`Montant transaction`), Nombre = sum(`Nombre transaction`))
         
         zip.map$Montant <- zip.map_grouped$Montant[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
         zip.map$Nombre  <- zip.map_grouped$Nombre[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
         #zip.map$id <- allzips$id[match(zip.map$code_agence_dab, allzips$code_agence_dab)]
         
         zip.map$label <- paste0("<div,class = 'container', style = 'color:#154360 '>
                <h4><center> Code Agence: ", zip.map$code_agence_dab ,"</center></h4></br>
                <center>" ,capitalize(zip.map$lib_agence),"</center><hr>",
                                 "<b>Montant transation:</b><span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                 prettyNum(round(zip.map$Montant*1e6), " ") ," (XOF)</span></br>",
                                 "<b>Nombre transation:</b>  <span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                 prettyNum( zip.map$Nombre, " ") ,"</span></br>",
                                 "<b>Adresse:</b><em>  ", zip.map$Adresse ,"</em></h3>
                </div>") %>% 
           lapply(htmltools::HTML)
         
       }
       #zip.map$id <- 1:nrow(zip.map)
     }
     
     colnames(zip.map)[7] <- "montant_transaction"
     colnames(zip.map)[8] <- "nbre_transaction"
     
     if (colorBy == "type_porteur") {
       # Palette couleur pour la carte
       colorData <- zip.map$type_porteur 
       #pal <- colorFactor("viridis", domain = colorData)
       pal <- colorFactor(c("#c50022", "#F1C40F"), domain = colorData)
     }
     if (colorBy == "nom_carte") { 
       colorData <- zip.map$nom_carte
       pal <- colorFactor(c("#c50022","#cc3300", "#F1C40F","#669900","#1F618D", "#cc0066","#66ff66","#336699"), domain = colorData)
     }
     if (colorBy == "reseau_carte") {
       colorData <- zip.map$reseau_carte
       pal <- colorFactor( c("#ff9900","#c50022", "#F1C40F","#ffcc00","#cccc00", "#ff9933","#cc0000","#336699"), colorData)
     }
     if (sizeBy == "montant_transaction" ){
       radius <-  zip.map$montant_transaction/200 %>% unique()
       
     }
     
     if (sizeBy == "nbre_transaction" ){
       radius <-  zip.map$nbre_transaction/2000  %>% unique()
       
     }
     
     zip.map$id <- 1:nrow(zip.map)
     
     leafletProxy("map", data = zip.map) %>% clearMarkers() %>% 
       clearShapes() %>%
       addCircleMarkers(lng = ~longitude,lat = ~latitude, radius = radius, layerId = ~id, opacity = 0.5,
                        stroke=FALSE, fillOpacity=0.5, fillColor= pal(colorData) ,
                        label = ~label, 
                        popup = ~label
       ) %>%
       addLegend("bottomleft", pal=pal, values= colorData, title=colorBy,
                 layerId="colorLegend")
     
     if (!is.null(input$somevalue)){
       dist <- 0.1
       lat <- 5.380577113918679
       lng <- -3.9776080094590562
       leafletProxy("map", data = zip.map) %>% 
         clearShapes() %>% clearMarkers() %>% 
         setView( lat =  lat, lng = lng, zoom = 8) %>% 
         fitBounds(lng - dist, lat - dist, lng + dist, lat + dist) %>% 
         addCircleMarkers(lng = ~longitude,lat = ~latitude, radius = radius, layerId = ~id,weight = 1, opacity = 0.5,
                          stroke = FALSE, fillOpacity = 0.5, fillColor = ~pal(colorData),color = "maroon",
                          label = ~label, 
                          popup = ~label ) %>%
         addLegend("bottomleft", pal=pal, values=colorData, title=colorBy,
                   layerId="colorLegend") 
     }
   }
    
    # if the checkbock statut is avalaible
    
    if (input$Id045 == "CLIENT SG"){
      
      allzips <- allzips %>% filter(type_porteur == "CLIENT SG")
      # Update zip.map when date is entered
      if (input$daterange1[1] > min.date | input$daterange1[2] < max.date ){
        zip.map <- allzips %>%
          group_by(code_agence_dab,nom_carte, reseau_carte) %>% 
          summarise(latitude  = mean(latitude),
                    longitude = mean(longitude),
                    `Montant transaction` = sum(montant_transaction),
                    `Nombre transaction`  = round(sum(nbre_transaction)),
                    Adresse = adresse, lib_ville, type_porteur, lib_agence, .groups = 'drop')  %>% unique()
        
        zip.map_grouped <- zip.map %>% group_by(code_agence_dab) %>% 
          summarise(Montant = sum(`Montant transaction`), Nombre = sum(`Nombre transaction`))
        
        zip.map$Montant <- zip.map_grouped$Montant[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
        zip.map$Nombre  <- zip.map_grouped$Nombre[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
        zip.map$id <-   allzips$ident[match(zip.map$code_agence_dab, allzips$code_agence_dab)]
        
        zip.map$label <- paste0("<div,class = 'container', style = 'color:#154360 '>
                <h4><center> Code Agence: ", zip.map$code_agence_dab ,"</center></h4></br>
                <center>" ,capitalize(zip.map$lib_agence),"</center><hr>",
                                "<b>Montant transation:</b><span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                prettyNum(round(zip.map$Montant*1e6), " ") ," (XOF)</span></br>",
                                "<b>Nombre transation:</b>  <span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                prettyNum( zip.map$Nombre, " ") ,"</span></br>",
                                "<b>Adresse:</b><em>  ", zip.map$Adresse ,"</em></h3>
                </div>") %>% 
          lapply(htmltools::HTML)
      }
      
      if (input$daterange1[1] != max.date | input$daterange1[2] != min.date ){
        if(lubridate::month(input$daterange1[1]) == lubridate::month(input$daterange1[2])){
          show_alert(
            title = "Erreur de date !!",
            text = "La période doit être comprise entre deux mois...",
            type = "warning",
            width = "400px"
          )
        }
        else{
          zip.map <- allzips[allzips$mois <= input$daterange1[2] & allzips$mois >= input$daterange1[1] ,] %>% 
            group_by(code_agence_dab, nom_carte, reseau_carte) %>% 
            summarise(latitude  = mean(latitude),
                      longitude = mean(longitude),
                      `Montant transaction` = sum(montant_transaction),
                      `Nombre transaction`  = round(sum(nbre_transaction)),
                      Adresse = adresse, lib_ville, lib_agence,type_porteur, .groups = 'drop')  %>% unique()
          
          zip.map_grouped <- zip.map %>% group_by(code_agence_dab) %>% 
            summarise(Montant = sum(`Montant transaction`), Nombre = sum(`Nombre transaction`))
          
          zip.map$Montant <- zip.map_grouped$Montant[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
          zip.map$Nombre  <- zip.map_grouped$Nombre[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
          zip.map$id <-   allzips$ident[match(zip.map$code_agence_dab, allzips$code_agence_dab)]
          
          zip.map$label <- paste0("<div,class = 'container', style = 'color:#154360 '>
                <h4><center> Code Agence: ", zip.map$code_agence_dab ,"</center></h4></br>
                <center>" ,capitalize(zip.map$lib_agence),"</center><hr>",
                                  "<b>Montant transation:</b><span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                  prettyNum(round(zip.map$Montant*1e6), " ") ," (XOF)</span></br>",
                                  "<b>Nombre transation:</b>  <span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                  prettyNum( zip.map$Nombre, " ") ,"</span></br>",
                                  "<b>Adresse:</b><em>  ", zip.map$Adresse ,"</em></h3>
                </div>") %>% 
            lapply(htmltools::HTML)
          
        }
        
      }
      
      colnames(zip.map)[colnames(zip.map) == "Montant"] <- "montant_transaction"
      colnames(zip.map)[colnames(zip.map) == "Nombre"] <- "nbre_transaction"
      
      if (colorBy == "type_porteur") {
        # Palette couleur pour la carte
        colorData <- zip.map$type_porteur 
        #pal <- colorFactor("viridis", domain = colorData)
        pal <- colorFactor(c("#c50022"), domain = colorData)
      }
      if (colorBy == "nom_carte") { 
        colorData <- zip.map$nom_carte
        pal <- colorFactor(c("#c50022","#cc3300", "#F1C40F","#669900","#1F618D", "#cc0066","#66ff66","#336699"), domain = colorData)
      }
      if (colorBy == "reseau_carte") {
        colorData <- zip.map$reseau_carte
        pal <- colorFactor( c("#ff9900","#c50022", "#F1C40F","#ffcc00","#cccc00", "#ff9933","#cc0000","#336699"), colorData)
      }
      if (sizeBy == "montant_transaction" ){
        radius <-  zip.map$montant_transaction/1000 %>% unique()
        
      }
      
      if (sizeBy == "nbre_transaction" ){
        radius <-  zip.map$nbre_transaction/3000  %>% unique()
        
      }
      
      #zip.map$id <- 1:nrow(zip.map)
      
      leafletProxy("map", data = zip.map) %>% clearMarkers() %>% 
        clearShapes() %>%
        addCircleMarkers(lng = ~longitude,lat = ~latitude, radius = radius, layerId = ~id, opacity = 0.5,
                         stroke=FALSE, fillOpacity=0.3, fillColor= pal(colorData) ,
                         label = ~label, 
                         popup = ~label
        ) %>%
        addLegend("bottomleft", pal=pal, values= colorData, title=colorBy,
                  layerId="colorLegend")
      
      if (!is.null(input$somevalue)){
        dist <- 0.1
        lat <- 5.380577113918679
        lng <- -3.9776080094590562
        leafletProxy("map", data = zip.map) %>% 
          clearShapes() %>% clearMarkers() %>% 
          setView( lat =  lat, lng = lng, zoom = 8) %>% 
          fitBounds(lng - dist, lat - dist, lng + dist, lat + dist) %>% 
          addCircleMarkers(lng = ~longitude,lat = ~latitude, radius = radius, layerId = ~id,weight = 1, opacity = 0.5,
                           stroke = FALSE, fillOpacity = 0.3, fillColor = ~pal(colorData),color = "maroon",
                           label = ~label, 
                           popup = ~label ) %>%
          addLegend("bottomleft", pal=pal, values=colorData, title=colorBy,
                    layerId="colorLegend") 
      }
      
    }
    if (input$Id045 == "Concurrent"){
      
      allzips <- allzips %>% filter(type_porteur == "Concurrent")
      # Update zip.map when date is entered
      if (input$daterange1[1] > min.date | input$daterange1[2] < max.date ){
        zip.map <- allzips %>%
          group_by(code_agence_dab,nom_carte, reseau_carte) %>% 
          summarise(latitude  = mean(latitude),
                    longitude = mean(longitude),
                    `Montant transaction` = sum(montant_transaction),
                    `Nombre transaction`  = round(sum(nbre_transaction)),
                    Adresse = adresse, lib_ville, type_porteur, lib_agence, .groups = 'drop')  %>% unique()
        
        zip.map_grouped <- zip.map %>% group_by(code_agence_dab) %>% 
          summarise(Montant = sum(`Montant transaction`), Nombre = sum(`Nombre transaction`))
        
        zip.map$Montant <- zip.map_grouped$Montant[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
        zip.map$Nombre  <- zip.map_grouped$Nombre[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
        zip.map$id <-   allzips$ident[match(zip.map$code_agence_dab, allzips$code_agence_dab)]
        
        zip.map$label <- paste0("<div,class = 'container', style = 'color:#154360 '>
                <h4><center> Code Agence: ", zip.map$code_agence_dab ,"</center></h4></br>
                <center>" ,capitalize(zip.map$lib_agence),"</center><hr>",
                                "<b>Montant transation:</b><span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                prettyNum(round(zip.map$Montant*1e6), " ") ," (XOF)</span></br>",
                                "<b>Nombre transation:</b>  <span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                prettyNum( zip.map$Nombre, " ") ,"</span></br>",
                                "<b>Adresse:</b><em>  ", zip.map$Adresse ,"</em></h3>
                </div>") %>% 
          lapply(htmltools::HTML)
      }
      
      if (input$daterange1[1] != max.date | input$daterange1[2] != min.date ){
        if(lubridate::month(input$daterange1[1]) == lubridate::month(input$daterange1[2])){
          show_alert(
            title = "Erreur de date !!",
            text = "La période doit être comprise entre deux mois...",
            type = "warning",
            width = "400px"
          )
        }
        else{
          zip.map <- allzips[allzips$mois <= input$daterange1[2] & allzips$mois >= input$daterange1[1] ,] %>% 
            group_by(code_agence_dab, nom_carte, reseau_carte) %>% 
            summarise(latitude  = mean(latitude),
                      longitude = mean(longitude),
                      `Montant transaction` = sum(montant_transaction),
                      `Nombre transaction`  = round(sum(nbre_transaction)),
                      Adresse = adresse, lib_ville, lib_agence,type_porteur, .groups = 'drop')  %>% unique()
          
          zip.map_grouped <- zip.map %>% group_by(code_agence_dab) %>% 
            summarise(Montant = sum(`Montant transaction`), Nombre = sum(`Nombre transaction`))
          
          zip.map$Montant <- zip.map_grouped$Montant[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
          zip.map$Nombre  <- zip.map_grouped$Nombre[match(zip.map$code_agence_dab, zip.map_grouped$code_agence_dab)]
          zip.map$id <-   allzips$ident[match(zip.map$code_agence_dab, allzips$code_agence_dab)]
          
          zip.map$label <- paste0("<div,class = 'container', style = 'color:#154360 '>
                <h4><center> Code Agence: ", zip.map$code_agence_dab ,"</center></h4></br>
                <center>" ,capitalize(zip.map$lib_agence),"</center><hr>",
                                  "<b>Montant transation:</b><span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                  prettyNum(round(zip.map$Montant*1e6), " ") ," (XOF)</span></br>",
                                  "<b>Nombre transation:</b>  <span style='color:maroon;font-weight:bold; font-size:15px'>  ",
                                  prettyNum( zip.map$Nombre, " ") ,"</span></br>",
                                  "<b>Adresse:</b><em>  ", zip.map$Adresse ,"</em></h3>
                </div>") %>% 
            lapply(htmltools::HTML)
          
        }
        
      }
      
      colnames(zip.map)[colnames(zip.map) == "Montant"] <- "montant_transaction"
      colnames(zip.map)[colnames(zip.map) == "Nombre"] <- "nbre_transaction"
      
      if (colorBy == "type_porteur") {
        # Palette couleur pour la carte
        colorData <- zip.map$type_porteur 
        #pal <- colorFactor("viridis", domain = colorData)
        pal <- colorFactor(c("#F1C40F"), domain = colorData)
      }
      if (colorBy == "nom_carte") { 
        colorData <- zip.map$nom_carte
        pal <- colorFactor(c("#c50022","#cc3300", "#F1C40F","#669900","#1F618D", "#cc0066","#66ff66","#336699"), domain = colorData)
      }
      if (colorBy == "reseau_carte") {
        colorData <- zip.map$reseau_carte
        pal <- colorFactor( c("#ff9900","#c50022", "#F1C40F","#ffcc00","#cccc00", "#ff9933","#cc0000","#336699"), colorData)
      }
      if (sizeBy == "montant_transaction" ){
        radius <-  zip.map$montant_transaction/200 %>% unique()
        
      }
      
      if (sizeBy == "nbre_transaction" ){
        radius <-  zip.map$nbre_transaction/3000  %>% unique()
        
      }
      
      #zip.map$id <- 1:nrow(zip.map)
      
      leafletProxy("map", data = zip.map) %>% clearMarkers() %>% 
        clearShapes() %>%
        addCircleMarkers(lng = ~longitude,lat = ~latitude, radius = radius, layerId = ~id, opacity = 0.5,
                         stroke=FALSE, fillOpacity=0.3, fillColor= pal(colorData) ,
                         label = ~label, 
                         popup = ~label
        ) %>%
        addLegend("bottomleft", pal=pal, values= colorData, title=colorBy,
                  layerId="colorLegend")
      
      if (!is.null(input$somevalue)){
        dist <- 0.1
        lat <- 5.380577113918679
        lng <- -3.9776080094590562
        leafletProxy("map", data = zip.map) %>% 
          clearShapes() %>% clearMarkers() %>% 
          setView( lat =  lat, lng = lng, zoom = 8) %>% 
          fitBounds(lng - dist, lat - dist, lng + dist, lat + dist) %>% 
          addCircleMarkers(lng = ~longitude,lat = ~latitude, radius = radius, layerId = ~id,weight = 1, opacity = 0.5,
                           stroke = FALSE, fillOpacity = 0.3, fillColor = ~pal(colorData),color = "maroon",
                           label = ~label, 
                           popup = ~label ) %>%
          addLegend("bottomleft", pal=pal, values=colorData, title=colorBy,
                    layerId="colorLegend") 
      }
      
    }
    
  })


  ## Data Explorer ###########################################
  
  observe({
    cities <- if (is.null(input$states)) character(0) else {
      cleantable %>% filter(`Region ou departement` %in% input$states) %>% `$`(Ville) %>% unique() %>% sort()
      }
    stillSelected <- isolate(input$cities[input$cities %in% cities])
    updateSelectizeInput(session, "cities", choices = cities,
      selected = stillSelected, server = TRUE)
  })
  
  
  observe({
    zipcodes <- if (is.null(input$states)) character(0) else {
      cleantable %>%
        filter(`Region ou departement` %in% input$states,
          is.null(input$cities) | Ville %in% input$cities) %>%
        `$`("Code") %>%
        unique() %>%
        sort()
    }
    stillSelected <- isolate(input$zipcodes[input$zipcodes %in% zipcodes])
    updateSelectizeInput(session, "zipcodes", choices = zipcodes,
      selected = stillSelected, server = TRUE)
  })
  
  observe({
    if (is.null(input$goto))
      return()
    isolate({
      map <- leafletProxy("map") %>% clearPopups()
      dist <- 0.1
      zip <- unique(input$goto$zip)
      lat <- input$goto$lat
      lng <- input$goto$lng
      provider <- sample(names(providers), 1, replace = TRUE)
      map  %>%  clearPopups() %>% 
        addCircles(lng = lng,lat = lat, radius =   cleantable[cleantable$Code == zip ,]$`Nombre transaction`/200, 
                   layerId = cleantable[cleantable$Code == zip ,]$Code, color = "purple", opacity = 0.8, fillOpacity = 0.5 ) %>% 
        addPopups(lng = lng, lat = lat, layerId = zip, popup = cleantable[cleantable$Code == zip ,]$content) %>% 
        fitBounds(lng - dist, lat - dist, lng + dist, lat + dist)
    })
  })

  output$ziptable <- DT::renderDataTable({
    df <- cleantable %>%
      filter(
        is.null(input$states) | `Region ou departement` %in% input$states,
        is.null(input$cities) | Ville %in% input$cities,
        is.null(input$zipcodes) | Code %in% input$zipcodes
      ) %>% select(-c(content)) %>% 
      mutate(Action = paste('<a class="go-map" href="" data-lat="', Lat, '" data-long="', Long, '" data-zip="', Code, '"><i class="fa fa-crosshairs"></i></a>', sep=""))
    action <- DT::dataTableAjax(session, df, outputId = "ziptable")
    DT::datatable(df, extensions = c("Buttons"), class = "cell-border stripe",
                  options = list(ajax = list(url = action), dom = 't',
                                 initComplete = JS(
                                   "function(settings, json) {",
                                   "$(this.api().table().header()).css({'background-color':'#1F618D' ,
                                   'color':'#fff', 'font-size':'10px'});", "}")
                                 ), escape = FALSE) %>% DT::formatStyle(columns = colnames(.$x$data), "font-size" = "10px")
  })
  
  
  
  
  ## Data exploratory ###########################################
  
  
  observe({
    
    if(input$datRange[2]  == max.date & input$datRange[1] == min.date){
      output$period <- renderText({
        paste0("2020-07-01"," || ", "2020-12-01")
      })
    }
    else {
      output$period <- renderText({
        paste0( as.character(input$datRange[1])," || ", as.character(input$datRange[2]))
      })
    }
  
    if(input$datRange[2]  < max.date | input$datRange[1] > min.date){
      if(lubridate::month(input$datRange[1]) == lubridate::month(input$datRange[2])){
        show_alert(
          title = "Erreur de date !!",
          #text = "La période doit être comprise entre deux mois...",
          tags$span(
            tags$p("La période doit être comprise entre deux mois...",
                    style = "color: steelblue;")),
          type = "warning",
          width = "400px"
        )
      }
      
       allzips <- allzips %>% dplyr::filter(input$datRange[1]  <= mois & mois <= input$datRange[2])
       
       if (is.null(input$xcol2)){
         montant <- sum(allzips$montant_transaction)
         transaction <- sum(allzips$nbre_transaction)
         
         output$info_montant <- renderInfoBox({
           infoBox("Montant des transactions",paste0(prettyNum(montant ," "), " (XOF)"), color = "maroon", 
                   icon = icon("list"))
         })
         output$info_transaction <- renderInfoBox({
           infoBox("Nombre de transaction", (prettyNum(transaction ," ")),
                   icon = icon("list"))
         })
         
         df_base <- allzips %>% group_by(type_porteur, reseau_carte, nom_carte) %>% 
           summarise(`Nombre` = round(sum(montant_transaction)),
                     `Transactions` = sum(montant_transaction),
                     .groups = 'drop'
           )
         
         #------------- Montant des transactions ------------------------
         if(input$ycol2 == "montant_transaction"){
           # Graphique des parts totale par type porteur
           output$plot3 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~reseau_carte,
                       y = ~Transactions,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~paste(Transactions, 'millions'),
                       showlegend = TRUE) %>%
               layout(
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
           })
           
           output$plot2 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~nom_carte,
                       y = ~Transactions,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~paste(Transactions, 'millions'),
                       showlegend = TRUE) %>%
               layout( 
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
             
           })
           
           if (input$check_transaction == "Type carte reseau"){
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(reseau_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
           
           if (input$check_transaction == "Nom de la carte") {
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(nom_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
           
         }
         
         # ---------- Nombre des transactions ----------------------
         else {
           # Graphique des parts totale par type porteur
           output$plot3 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~reseau_carte,
                       y = ~Nombre,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~paste0(Nombre, " transactions"),
                       showlegend = TRUE) %>%
               layout(
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
           })
           
           output$plot2 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~nom_carte,
                       y = ~Nombre,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~ paste0(Nombre, " transactions"),
                       showlegend = TRUE) %>%
               layout(
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
             
           })
           
           if (input$check_transaction == "Nom de la carte") {
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(nom_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
           if (input$check_transaction == "Type carte reseau"){
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(reseau_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
         }
       }# End of the case any agency chosen !
       
       else {
         allzips <- allzips[allzips$agence_dab %in% input$xcol2, ]
         montant <- sum(allzips$montant_transaction)
         transaction <- sum(allzips$nbre_transaction)
         
         output$info_montant <- renderInfoBox({
           infoBox("Montant des transactions",paste0(prettyNum(montant ," "), " ( XOF )"), color = "maroon", 
                   icon = icon("list"))
         })
           
           output$info_transaction <- renderInfoBox({
             infoBox("Nombre de transaction", (prettyNum(transaction ," ")),
                     icon = icon("list"))
           })
         
         df_base <- allzips %>% group_by(type_porteur, reseau_carte, nom_carte) %>% 
           summarise(`Nombre` = round(sum(montant_transaction)),
                     `Transactions` = sum(montant_transaction),
                     .groups = 'drop'
           )
         
         #------------- Montant des transactions ------------------------
         if(input$ycol2 == "montant_transaction"){
           # Graphique des parts totale par type porteur
           output$plot3 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~reseau_carte,
                       y = ~Transactions,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~paste(Transactions, 'millions'),
                       showlegend = TRUE) %>%
               layout(
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
           })
           
           output$plot2 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~nom_carte,
                       y = ~Transactions,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~paste(Transactions, 'millions'),
                       showlegend = TRUE) %>%
               layout( 
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
             
           })
           
           if (input$check_transaction == "Nom de la carte") {
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(nom_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
           if (input$check_transaction == "Type carte reseau"){
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(reseau_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
           
         }
         
         # ---------- Nombre des transactions ----------------------
         else {
           # Graphique des parts totale par type porteur
           output$plot3 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~reseau_carte,
                       y = ~Nombre,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~paste0(Nombre, " transactions"),
                       showlegend = TRUE) %>%
               layout(
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
           })
           
           output$plot2 <- renderPlotly({
             df_base %>% 
               rename(`Type porteur` = type_porteur) %>% 
               plot_ly(type = "bar",
                       x = ~nom_carte,
                       y = ~Nombre,
                       color = ~`Type porteur` ,
                       colors = rep(c("#c50022", "#F1C40F"),each=4),
                       hoverinfo = 'text',
                       text = ~ paste0(Nombre, " transactions"),
                       showlegend = TRUE) %>%
               layout(
                 xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                 yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
             
           })
           
           if (input$check_transaction == "Nom de la carte") {
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(nom_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
           if (input$check_transaction == "Type carte reseau"){
             output$plot4 <- renderPlotly({
               count.data <- allzips %>% group_by(reseau_carte) %>% 
                 summarise(`Nombre` = sum(montant_transaction)/1e6,
                           `Transactions` = sum(montant_transaction)/1e6,
                           .groups = 'drop'
                 ) 
               
               tot.transaction <- sum(count.data$Transactions)
               count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
               
               fig <- count.data %>% 
                 arrange(desc(lab.ypos)) %>%
                 plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                         textposition = 'inside',
                         textinfo = 'label+percent',
                         insidetextfont = list(color = '#FFFFFF'),
                         hoverinfo = 'text',
                         text = ~paste(Transactions, 'millions'),
                         marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                       line = list(color = '#FFFFFF', width = 1)),
                         #The 'pull' attribute can also be used to create space between the sectors
                         showlegend = TRUE) %>%
                 layout(
                   xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                   yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
               
               fig
             })
           }
         }
         
       }
    }
    
   
    
  # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
     # Case where date is not chosen
    else{
      
      output$info_date <- renderInfoBox({
        infoBox("Période d'analyse", paste0("Du", input$datRange[1],"au", input$datRange[2]), color = "maroon", 
                icon = icon("list"))
      })
      if (is.null(input$xcol2)){
      montant <- sum(allzips$montant_transaction)*1e6
      transaction <- sum(allzips$nbre_transaction)
      
      output$info_montant <- renderInfoBox({
        infoBox("Montant des transactions",paste0(prettyNum(montant ," "), " ( XOF )"), color = "maroon", 
                icon = icon("list"))
      })
      output$info_transaction <- renderInfoBox({
        infoBox("Nombre de transaction", (prettyNum(transaction ," ")),
                icon = icon("list"))
      })
      
     
      df_base <- allzips %>% group_by(type_porteur, reseau_carte, nom_carte) %>% 
        summarise(`Nombre` = round(sum(montant_transaction)),
                  `Transactions` = sum(montant_transaction),
                  .groups = 'drop'
        )
      
    #------------- Montant des transactions ------------------------
      if(input$ycol2 == "montant_transaction"){
      # Graphique des parts totale par type porteur
      output$plot3 <- renderPlotly({
        df_base %>% 
              rename(`Type porteur` = type_porteur) %>% 
              plot_ly(type = "bar",
                    x = ~reseau_carte,
                    y = ~Transactions,
                    color = ~`Type porteur` ,
                    colors = rep(c("#c50022", "#F1C40F"),each=4),
                    hoverinfo = 'text',
                    text = ~paste(Transactions, 'millions'),
                    showlegend = TRUE) %>%
              layout(
                xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
      })
      
      output$plot2 <- renderPlotly({
        df_base %>% 
          rename(`Type porteur` = type_porteur) %>% 
          plot_ly(type = "bar",
                x = ~nom_carte,
                y = ~Transactions,
                color = ~`Type porteur` ,
                colors = rep(c("#c50022", "#F1C40F"),each=4),
                hoverinfo = 'text',
                text = ~paste(Transactions, 'millions'),
                showlegend = TRUE) %>%
                layout( 
                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
              
      })
        
      if (input$check_transaction == "Nom de la carte") {
        output$plot4 <- renderPlotly({
          count.data <- allzips %>% group_by(nom_carte) %>% 
            summarise(`Nombre` = sum(montant_transaction)/1e6,
                      `Transactions` = sum(montant_transaction)/1e6,
                      .groups = 'drop'
            ) 
          
          tot.transaction <- sum(count.data$Transactions)
          count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
          
          fig <- count.data %>% 
            arrange(desc(lab.ypos)) %>%
            plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                    textposition = 'inside',
                    textinfo = 'label+percent',
                    insidetextfont = list(color = '#FFFFFF'),
                    hoverinfo = 'text',
                    text = ~paste(Transactions, 'millions'),
                    marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                  line = list(color = '#FFFFFF', width = 1)),
                    #The 'pull' attribute can also be used to create space between the sectors
                    showlegend = TRUE) %>%
            layout(
              xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
              yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
          
          fig
        })
      }
      if (input$check_transaction == "Type carte reseau"){
        output$plot4 <- renderPlotly({
          count.data <- allzips %>% group_by(reseau_carte) %>% 
            summarise(`Nombre` = sum(montant_transaction)/1e6,
                      `Transactions` = sum(montant_transaction)/1e6,
                      .groups = 'drop'
            ) 
          
          tot.transaction <- sum(count.data$Transactions)
          count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
          
          fig <- count.data %>% 
            arrange(desc(lab.ypos)) %>%
            plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                    textposition = 'inside',
                    textinfo = 'label+percent',
                    insidetextfont = list(color = '#FFFFFF'),
                    hoverinfo = 'text',
                    text = ~paste(Transactions, 'millions'),
                    marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                  line = list(color = '#FFFFFF', width = 1)),
                    #The 'pull' attribute can also be used to create space between the sectors
                    showlegend = TRUE) %>%
            layout(
              xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
              yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
          
          fig
        })
      }
        
      }
      
    # ---------- Nombre des transactions ----------------------
      else {
        # Graphique des parts totale par type porteur
        output$plot3 <- renderPlotly({
          df_base %>% 
            rename(`Type porteur` = type_porteur) %>% 
            plot_ly(type = "bar",
                    x = ~reseau_carte,
                    y = ~Nombre,
                    color = ~`Type porteur` ,
                    colors = rep(c("#c50022", "#F1C40F"),each=4),
                    hoverinfo = 'text',
                    text = ~paste0(Nombre, " transactions"),
                    showlegend = TRUE) %>%
            layout(
              xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
              yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
        })
        
        output$plot2 <- renderPlotly({
          df_base %>% 
            rename(`Type porteur` = type_porteur) %>% 
            plot_ly(type = "bar",
                    x = ~nom_carte,
                    y = ~Nombre,
                    color = ~`Type porteur` ,
                    colors = rep(c("#c50022", "#F1C40F"),each=4),
                    hoverinfo = 'text',
                    text = ~ paste0(Nombre, " transactions"),
                    showlegend = TRUE) %>%
            layout(
              xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
              yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
          
        })
        
        if (input$check_transaction == "Nom de la carte") {
          output$plot4 <- renderPlotly({
            count.data <- allzips %>% group_by(nom_carte) %>% 
              summarise(`Nombre` = sum(montant_transaction)/1e6,
                        `Transactions` = sum(montant_transaction)/1e6,
                        .groups = 'drop'
              ) 
            
            tot.transaction <- sum(count.data$Transactions)
            count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
            
            fig <- count.data %>% 
              arrange(desc(lab.ypos)) %>%
              plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                      textposition = 'inside',
                      textinfo = 'label+percent',
                      insidetextfont = list(color = '#FFFFFF'),
                      hoverinfo = 'text',
                      text = ~paste(Transactions, 'millions'),
                      marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                    line = list(color = '#FFFFFF', width = 1)),
                      #The 'pull' attribute can also be used to create space between the sectors
                      showlegend = TRUE) %>%
              layout(
                xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
            
            fig
          })
        }
        if (input$check_transaction == "Type carte reseau"){
          output$plot4 <- renderPlotly({
            count.data <- allzips %>% group_by(reseau_carte) %>% 
              summarise(`Nombre` = sum(montant_transaction)/1e6,
                        `Transactions` = sum(montant_transaction)/1e6,
                        .groups = 'drop'
              ) 
            
            tot.transaction <- sum(count.data$Transactions)
            count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
            
            fig <- count.data %>% 
              arrange(desc(lab.ypos)) %>%
              plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                      textposition = 'inside',
                      textinfo = 'label+percent',
                      insidetextfont = list(color = '#FFFFFF'),
                      hoverinfo = 'text',
                      text = ~paste(Transactions, 'millions'),
                      marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                    line = list(color = '#FFFFFF', width = 1)),
                      #The 'pull' attribute can also be used to create space between the sectors
                      showlegend = TRUE) %>%
              layout(
                xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
            
            fig
          })
        }
      }
      }# End of the case any agency chosen !
    
      #   Traitement du cas ou une agence ou +sieurs choisies !
      else {
        allzips <- allzips[allzips$agence_dab %in% input$xcol2, ]
        montant <- sum(allzips$montant_transaction)*1e6
        transaction <- sum(allzips$nbre_transaction)
        
        output$info_montant <- renderInfoBox({
          infoBox("Montant des transactions",paste0(prettyNum(montant ," "), " (XOF)"), color = "maroon", 
                  icon = icon("list"))
        })
        output$info_transaction <- renderInfoBox({
          infoBox("Nombre de transaction", (prettyNum(transaction ," ")),
                  icon = icon("list"))
        })
        
        df_base <- allzips %>% group_by(type_porteur, reseau_carte, nom_carte) %>% 
          summarise(`Nombre` = round(sum(montant_transaction)),
                    `Transactions` = sum(montant_transaction),
                    .groups = 'drop'
          )
        
        #------------- Montant des transactions ------------------------
        if(input$ycol2 == "montant_transaction"){
          # Graphique des parts totale par type porteur
          output$plot3 <- renderPlotly({
            df_base %>% 
              rename(`Type porteur` = type_porteur) %>% 
              plot_ly(type = "bar",
                      x = ~reseau_carte,
                      y = ~Transactions,
                      color = ~`Type porteur` ,
                      colors = rep(c("#c50022", "#F1C40F"),each=4),
                      hoverinfo = 'text',
                      text = ~paste(Transactions, 'millions'),
                      showlegend = TRUE) %>%
              layout(
                xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
          })
          
          output$plot2 <- renderPlotly({
            df_base %>% 
              rename(`Type porteur` = type_porteur) %>% 
              plot_ly(type = "bar",
                      x = ~nom_carte,
                      y = ~Transactions,
                      color = ~`Type porteur` ,
                      colors = rep(c("#c50022", "#F1C40F"),each=4),
                      hoverinfo = 'text',
                      text = ~paste(Transactions, 'millions'),
                      showlegend = TRUE) %>%
              layout( 
                xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
            
          })
          
          if (input$check_transaction == "Nom de la carte") {
            output$plot4 <- renderPlotly({
              count.data <- allzips %>% group_by(nom_carte) %>% 
                summarise(`Nombre` = sum(montant_transaction)/1e6,
                          `Transactions` = sum(montant_transaction)/1e6,
                          .groups = 'drop'
                ) 
              
              tot.transaction <- sum(count.data$Transactions)
              count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
              
              fig <- count.data %>% 
                arrange(desc(lab.ypos)) %>%
                plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = '#FFFFFF'),
                        hoverinfo = 'text',
                        text = ~paste(Transactions, 'millions'),
                        marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                      line = list(color = '#FFFFFF', width = 1)),
                        #The 'pull' attribute can also be used to create space between the sectors
                        showlegend = TRUE) %>%
                layout(
                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
              
              fig
            })
          }
          if (input$check_transaction == "Type carte reseau"){
            output$plot4 <- renderPlotly({
              count.data <- allzips %>% group_by(reseau_carte) %>% 
                summarise(`Nombre` = sum(montant_transaction)/1e6,
                          `Transactions` = sum(montant_transaction)/1e6,
                          .groups = 'drop'
                ) 
              
              tot.transaction <- sum(count.data$Transactions)
              count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
              
              fig <- count.data %>% 
                arrange(desc(lab.ypos)) %>%
                plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = '#FFFFFF'),
                        hoverinfo = 'text',
                        text = ~paste(Transactions, 'millions'),
                        marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                      line = list(color = '#FFFFFF', width = 1)),
                        #The 'pull' attribute can also be used to create space between the sectors
                        showlegend = TRUE) %>%
                layout(
                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
              
              fig
            })
          }
          
        }
        
        # ---------- Nombre des transactions ----------------------
        else {
          # Graphique des parts totale par type porteur
          output$plot3 <- renderPlotly({
            df_base %>% 
              rename(`Type porteur` = type_porteur) %>% 
              plot_ly(type = "bar",
                      x = ~reseau_carte,
                      y = ~Nombre,
                      color = ~`Type porteur` ,
                      colors = rep(c("#c50022", "#F1C40F"),each=4),
                      hoverinfo = 'text',
                      text = ~paste0(Nombre, " transactions"),
                      showlegend = TRUE) %>%
              layout(
                xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
          })
          
          output$plot2 <- renderPlotly({
            df_base %>% 
              rename(`Type porteur` = type_porteur) %>% 
              plot_ly(type = "bar",
                      x = ~nom_carte,
                      y = ~Nombre,
                      color = ~`Type porteur` ,
                      colors = rep(c("#c50022", "#F1C40F"),each=4),
                      hoverinfo = 'text',
                      text = ~ paste0(Nombre, " transactions"),
                      showlegend = TRUE) %>%
              layout(
                xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = TRUE),
                yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
            
          })
          
          if (input$check_transaction == "Nom de la carte") {
            output$plot4 <- renderPlotly({
              count.data <- allzips %>% group_by(nom_carte) %>% 
                summarise(`Nombre` = sum(montant_transaction)/1e6,
                          `Transactions` = sum(montant_transaction)/1e6,
                          .groups = 'drop'
                ) 
              
              tot.transaction <- sum(count.data$Transactions)
              count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
              
              fig <- count.data %>% 
                arrange(desc(lab.ypos)) %>%
                plot_ly(type='pie', labels = ~nom_carte, values= ~lab.ypos, 
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = '#FFFFFF'),
                        hoverinfo = 'text',
                        text = ~paste(Transactions, 'millions'),
                        marker = list(colors = c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                      line = list(color = '#FFFFFF', width = 1)),
                        #The 'pull' attribute can also be used to create space between the sectors
                        showlegend = TRUE) %>%
                layout(
                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
              
              fig
            })
          }
          if (input$check_transaction == "Type carte reseau"){
            output$plot4 <- renderPlotly({
              count.data <- allzips %>% group_by(reseau_carte) %>% 
                summarise(`Nombre` = sum(montant_transaction)/1e6,
                          `Transactions` = sum(montant_transaction)/1e6,
                          .groups = 'drop'
                ) 
              
              tot.transaction <- sum(count.data$Transactions)
              count.data$lab.ypos = round(count.data$Transactions*100/tot.transaction,2)
              
              fig <- count.data %>% 
                arrange(desc(lab.ypos)) %>%
                plot_ly(type='pie', labels = ~reseau_carte, values= ~lab.ypos, 
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = '#FFFFFF'),
                        hoverinfo = 'text',
                        text = ~paste(Transactions, 'millions'),
                        marker = list(colors =  c("#c50022","#F52887","#660066","#1F618D ","#cc0066","#002b80","#ffcc00","#33ccff" ),
                                      line = list(color = '#FFFFFF', width = 1)),
                        #The 'pull' attribute can also be used to create space between the sectors
                        showlegend = TRUE) %>%
                layout(
                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
              
              fig
            })
          }
        }
        
      }
      }# End of the case any date chosen ! 

  })# End Observe
  
 
  
}
