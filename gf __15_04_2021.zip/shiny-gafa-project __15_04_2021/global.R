

library(leaflet)
library(RColorBrewer)
library(scales)
library(lattice)
library(dplyr)
library(htmltools)
library(htmlwidgets)
library(ggplot2)
library(hrbrthemes)
library(viridis)
library(stringr)
library(Hmisc)



firstup <- function(x) {
  substr(x, 1, 1) <- toupper(substr(x, 1, 1))
  x
}

setwd("~/PROJET GAFA/shiny-gafa-project/")
allzips <- readRDS("data/dfmap.rds")
allzips <- allzips[!is.na(allzips$latitude)&!is.na(allzips$longitude)& 
                     !is.na(allzips$nom_carte)& !is.na(allzips$reseau_carte),]
allzips$nbre_transaction <- as.numeric(allzips$nbre_transaction)
allzips$montant_transaction <- as.numeric(allzips$montant_transaction)
allzips$ident <- 1:nrow(allzips)

allzips[allzips$nom_carte == "0",]$nom_carte <- "INCONNU"
allzips$montant_transaction <- allzips$montant_transaction/1e6
allzips$adresse <- firstup(tolower(allzips$adresse))
allzips$mois <- lubridate::ymd(allzips$mois)
allzips$reseau_carte <- capitalize(allzips$reseau_carte)

max.date <- max(allzips$mois, na.rm = TRUE)
min.date <- min(allzips$mois, na.rm = TRUE)

cleantable <- allzips %>%
  select(
    Ville  = lib_ville,
    Agence = lib_agence,
    Code   = code_agence_dab,
    `Nom de la carte` = nom_carte,
    `Réseau de la carte` = reseau_carte,
    `Montant des transactions` = montant_transaction,
    `Nombre de transactions`   = nbre_transaction,
    Adresse = adresse,
    `Region ou departement` = dept_region.x,
    `Type porteur` = type_porteur,
    Mois = mois,
    Lat  = latitude,
    Long = longitude
  ) %>%  filter(!is.na(Lat) & !is.na(Long))


cleantable <-  cleantable %>% group_by(Code) %>% 
                              summarise(
                                `Montant transaction` = sum(`Montant des transactions`),
                                `Nombre transaction` = sum(`Nombre de transactions`),
                                 .groups = 'drop',Adresse, Lat, Long, 
                                `Region ou departement`, Ville, Agence) %>%
                                 unique()


cleantable$content <- paste0("<div,class = 'container', style = 'color:#154360 '>
              <h4><center> Code Agence: ", cleantable$Code ,"</center></h4></br>
              <center>" ,capitalize(cleantable$Agence),"</center><hr>",
              "<b>Montant transation:</b><span style='color:maroon;font-weight:bold; font-size:15px'>  ",
              prettyNum(round(cleantable$`Montant transaction`*1e6), " ") ," (XOF)</span></br>",
              "<b>Nombre transation:</b>  <span style='color:maroon;font-weight:bold; font-size:15px'>  ",
              prettyNum(cleantable$`Nombre transaction`, " ") ,"</span></br>",
              "<b>Adresse:</b><em>  ", cleantable$Adresse ,"</em></h3>
              </div>" ) %>% 
              lapply(htmltools::HTML)


icon.fa <- makeAwesomeIcon(
  icon = "bank", markerColor = "#ff0066",
  library = "fa",
  iconColor = "black"
)

# Show a popup at the given location
showZipcodePopup <- function(zipcode, lat, lng) {
  selectedZip <- zip.map[zip.map$code_agence_dab == as.character(zipcode),]
  content <- zip.map$label
  leafletProxy("map") %>% addPopups(lng, lat, content, layerId = zipcode)
}

mycols <- c("#0077C8", "#EFC000FF", "#868686FF", "#CD534CFF","#0073C2FF" , "#7FBBE3" , "#BFDDF1" , "#00BC87")
